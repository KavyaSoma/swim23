@extends('layouts.main')
@section('content')
@if(session()->has('message.level'))
    <div class="alert alert-{{ session('message.level') }}" style="margin:13px;text-align: center;">
    {!! session('message.content') !!}
    </div>
    @endif
 <!-- Dashboard code starts here -->
<div class="container" id="main-code">
  <section class="main" style="margin-top:20px">
    <section class="tab-content">
      <section class="tab-pane active fade in active">
        <div class="row" id="dashboard-mob">
              <div class="col-xs-12 col-sm-4">
                <div class="panel panel-default">
                  <div class="panel-heading">
                    <a href="#"><i class="fa fa-plus-circle" style="color:#46A6EA;"></i></a> Add User
                  </div>
                    <div class="panel-body">
                      <form class="form-horizontal" action="{{url('admindashboard')}}" method="post">
                        {{csrf_field()}}
                       <div class="form-group">
                          <label class="control-label col-sm-4" for="txt">User Name:</label>
                          <div class="col-sm-6">
                          <input type="text" class="form-control" id="username" name="username" onchange="input('{{ url('register') }}')" required>
                          <div class="error-list" style="color: red;"></div>
                          </div>
                          </div>
                           <div class="form-group">
                          <label class="control-label col-sm-4" for="mail">Email:</label>
                          <div class="col-sm-6">
                          <input type="email" class="form-control" id="email" name="email" onchange="emailcheck()"  required>
                           <div class="error-email" style="color:red;"></div>
                          </div>
                        </div>
                          <div class="form-group">
                          <label class="control-label col-sm-4" for="pwd">Password:</label>
                          <div class="col-sm-6">
                          <input type="password" class="form-control" id="password" name="password" onchange="password('{{url('register')}}')" required>
                            <div id="pass" style="color: red;display:none"><li>Invalid Password</li></div>
                          </div>
                          </div>
                          <div class="form-group">
                            <label class="control-label col-sm-4" for="txt">User Type:</label>
                              <div class="col-sm-6">
                            <select class="form-control" id="sel" name="user_type">
                              <option>Club Admin</option>
                              <option>Venue Admin</option>
                              <option>System Admin</option>
                              <option>Instructor</option>
                          </select>
                          </div>
                          </div>
                          <div class="form-group">
                                <div class="col-sm-6">
                          <input type="hidden" class="form-control" id="display" name="shortname" readonly>
                          </div>
                          </div>
                          <center><button type="submit" class="btn btn-primary">Submit</button></center>
                        </div>
                      </form>
                       </div>
                      </div>
                      <div class="col-xs-12 col-sm-8">
                        <div class="panel panel-default magic-element isotope-item">
                                  <div class="panel-body-heading edituser_panel">
                                      <h4 class="pb-title" style="padding:5px">Edit User</h4>
                                  </div>
                                  <div class="panel-body">
                                  <div class="col-xs-4 col-sm-3">
                                   
                                  </div>
                                 
                                  <div class="col-xs-4 col-sm-offset-5 col-sm-3">
                                    <div class="form-group">
                                      <input type="text" class="form-control" id="txt" placeholder="Search..">
                                    </div>
                                  </div>
                                  <div class="table table-responsive">
                                    <table class="table table-bordered table-striped">
                                      <thead>
                                      <tr>
                                        <th>S.no</th>
                                        <th>User Name</th>
                                        <th>User Type</th>
                                        <th>Email</th>
                                        <th>Edit/Delete</th>
                                        </tr>
                                      </thead>
                                      @foreach($users as $user)
                                        <tbody>
                                          <tr>
                                            <td>{{$user->UserId}}</td>
                                            <td>{{$user->UserName}}</td>
                                            <td>{{$user->UserType}}</td>
                                            <td>{{$user->Email}}</td>
                                            <td><a href="#" class="icon-block"><i class="fa fa-edit user_edit" title="Edit"></i></a> / <a href="#" class="icon-block"><i class="fa fa-trash user_delete"</i></a></td>
                                          </tr>
                                         
                                        </tbody>
                                        @endforeach
                                    </table>
                                </div>
                                @if(count($users)>0)
 <div class="text-center">
   <ul class="pagination">
{{ $users->links() }}
 </ul>
 </div>
</div>
@endif
                              </div>
  </div>
  </div>
  <div class="col-xs-12 col-sm-4 post_news">
    <h4 style="color:#46A6EA;">News</h4>
    <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
       <div class="panel panel-default active col-md-12">
                    <div class="panel-heading" style="margin-left:-15px;margin-right:-15px;background:#46A6EA;color:#fff"  role="tab" id="headingOne">
                        <h3 class="panel-title">
                            <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                          Upcoming</a>
                        </h3>
                    </div>
                    <div id="collapseOne" class="panel-collapse collapse in"  role="tabpanel" aria-labelledby="headingOne">
                    <div class="panel-body"  id="user_scroll">
                        <ul class="media-list">
                          <li class="media">
                              <div class="media-left">
                                <img src="{{url('public/images/sravan.jpeg')}}" class="img-circle" width="65px" height="65px">
                              </div>
                              <div class="media-body">
                                <p><b> User</b></p>
                                <p>Instructor added to club.</p>
                              </div>
                        </li>
                        <li class="media">
                            <div class="media-left">
                              <img src="{{url('public/images/sravan.jpeg')}}" class="img-circle" width="65px" height="65px">
                            </div>
                            <div class="media-body">
                              <p><b> User</b></p>
                              <p>Venue is added.</p>
                            </div>
                      </li>
                      <li class="media">
                          <div class="media-left">
                            <img src="{{url('public/images/sravan.jpeg')}}" class="img-circle" width="65px" height="65px">
                          </div>
                          <div class="media-body">
                            <p><b> User</b></p>
                            <p>Event added to club.</p>
                          </div>
                    </li>
                        </ul>
                      </div>
                </div>
                <!-- End fluid width widget -->
              </div>
            <div class="panel panel-default col-xs-12 col-sm-12">
            <div class="panel-heading" style="margin-left:-15px;margin-right:-15px;background:#46A6EA;color:#fff"  role="tab" id="headingTwo">
                <h3 class="panel-title"><a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                   completed</a>
                </h3>
            </div>
                <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
            <div class="panel-body"  id="user_scroll">
              <ul class="media-list">
                <li class="media">
                    <div class="media-left">
                      <img src="images/sravan.jpeg" class="img-circle" width="65px" height="65px">
                    </div>
                    <div class="media-body">
                      <p><b> User</b></p>
                      <p>Event added to club</p>
                    </div>
              </li>
              <li class="media">
                  <div class="media-left">
                    <img src="images/sravan.jpeg" class="img-circle" width="65px" height="65px">
                  </div>
                  <div class="media-body">
                    <p><b> User</b></p>
                    <p>Instructor added to club</p>
                  </div>
            </li>
            <li class="media">
                <div class="media-left">
                  <img src="images/sravan.jpeg" class="img-circle" width="65px" height="65px">
                </div>
                <div class="media-body">
                  <p><b> User</b></p>
                  <p>Swimmer is at an Event</p>
                </div>
          </li>
        </ul>
          </div>
        </div>
      </div>
      </div>
    </div>
    </div>
  </section>
  </section>
  </section>
</div>
 <!-- Dashboard code ends here -->
 @endsection