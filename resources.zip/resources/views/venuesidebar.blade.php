<div class="col-xs-12 col-sm-4">
  @foreach($venues as $venue)
      <img class="img-responsive venue_image" src="{{url('public/images/swimm8.jpg')}}" alt="venue"/>
      <h5 style="color:#46A6EA">Venue Name</h5>
      <p>{{$venue->VenueName}}</P>
        @foreach($address as $add)
      <i class="fa fa-map-marker" style="color:#46A6EA"></i> {{$add->Country}}
      @endforeach
      <h5 style="color:#46A6EA">Opening Hours</h5>
      <p>Monday-wednesday(8:00 AM to 3:00 PM)<br>
        Thursday-saturday(6:00 AM to 1:00 PM)<br>
        Sunday(6:00 AM to 11:00 AM)</p>
      <h5 style="color:#46A6EA">Facilities</h5>
      <div class="row">
        @if($venue->ParaSwimmingFacilities == "yes")
        <div class="col-xs-2 col-sm-2">
      <img src="{{url('public/images/paraswimming.jpg')}}" height="30px" width="30px" alt="paraswimming" title="Paraswimming"/>
        </div>
        @endif
        @if($venue->Parking == "yes")
      <div class="col-xs-2 col-sm-2">
          <img src="{{url('public/images/parking.jpg')}}" height="30px" width="30px" alt="parking" title="Parking"/>
      </div>
      @endif
      @if($venue->LadiesOnlySwimming == 'yes')
        <div class="col-xs-2 col-sm-2">
          <img src="{{url('public/images/swimpool.jpg')}}" height="30px" width="30px" alt="pool" title="Ladies Only Swimming"/>
         </div>
         @endif
         @if($venue->Shower == "yes")
          <div class="col-xs-2 col-sm-2">
              <img src="{{url('public/images/shower.png')}}" height="30px" width="30px" alt="shower" title="Shower"/>
           </div>
           @endif
           @if($venue->PrivateHire == "yes")
            <div class="col-xs-2 col-sm-2">
                  <img src="{{url('public/images/privatehire.png')}}" height="30px" width="30px" alt="food" title="Food Court"/>
             </div>
             @endif
           </div><br>
              <div class="row">
                @if($venue->Gym == "yes")
               <div class="col-xs-2 col-sm-2">
                  <img src="{{url('public/images/gym.jpg')}}" height="30px" width="30px" alt="gym" title="Gym"/>
                </div>
                @endif
                @if($venue->Diving == "yes")
                  <div class="col-xs-2 col-sm-2">
                    <img src="{{url('public/images/diving.png')}}"  height="30px" width="30px"  alt="diving" title="Diving"/>
                  </div>
                  @endif
                  @if($venue->SwimForKids = "yes")
                    <div class="col-xs-2 col-sm-2">
                      <img src="{{url('public/images/kidszone.png')}}"  height="30px" width="30px"  alt="Kids Zone" title="Kids Zone"/>
                    </div>
                    @endif
                    @if($venue->Teachers == "yes")
                      <div class="col-xs-2 col-sm-2">
                        <img src="{{url('public/images/instructors.png')}}"  height="30px" width="30px"  alt="Instructors" title="instructors"/>
                      </div>
                      @endif
                      @if($venue->Toilets == "yes")
                      <div class="col-xs-2 col-sm-2">
                        <img src="{{url('public/images/instructors.png')}}"  height="30px" width="30px"  alt="Instructors" title="instructors"/>
                      </div>
                      @endif
       @if($venue->VisitingGallery == "yes")
         <div class="col-xs-2 col-sm-2">
                  <img src="{{url('public/images/VisitingGallery.png')}}" height="30px" width="30px" alt="gym" title="Gym"/>
                </div>
                @endif
                </div><br>
                      <div class="row">
              @if($venue->LadiesOnlySwimTimes == "yes")
                 <div class="col-xs-2 col-sm-2">
                  <img src="{{url('public/images/ladiesonlyswimmtime.png')}}" height="30px" width="30px" alt="gym" title="Gym"/>
                </div>
                @endif
      </div>
    <br>
      <center>
       @if(count($bridgemembers)>0)
        @if($bridgemembers[0]->ApproveStatus == 'pending')
        <a href="{{url('/venue/'.$venue->ShortName)}}"><button class="btn btn-primary">Request Sent</button></a>
        @elseif($bridgemembers[0]->ApproveStatus == 'accepted')
        <a href="{{url('/venue/'.$venue->ShortName)}}"><button class="btn btn-primary">Accepted</button></a>
        @elseif($bridgemembers[0]->ApproveStatus == 'rejected')
        <a href="{{url('/venue/'.$venue->ShortName)}}"><button class="btn btn-primary">Rejected</button></a>
         @endif
        @else
        <a href="{{url('/venue/'.$venue->ShortName.'/join')}}"><button class="btn btn-primary">Join Now</button></a>
        
        @endif
        <a href="{{url('addevent')}}"><button class="btn btn-primary">Book An Event</button></a>
  
    </div>
    @endforeach