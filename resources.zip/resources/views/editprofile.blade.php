  @extends('layouts.main')
@section('content')

@if(session()->has('message.level'))
    <div class="alert alert-{{ session('message.level') }}" style="margin:13px;text-align: center;">
    {!! session('message.content') !!}
    </div>
    @endif
<!-- settings information code starts here -->
  <div class="container" id="main-code">
     <div class="col-xs-12 col-sm-6 col-md-2 col-lg-2" id=kin_photo>
      @if($users[0]->Image=="NA")
     <div class="fb-profile"  style="margin-top:21%">
 <img class="thumbnail user_image"  src="{{url('public/images/profile.png')}}" width="200px" height="190px"  alt="Profile image"/>
 <button class="btn btn-default" style="margin-top:-100px" onclick="imgupload()"><i class="fa fa-edit" aria-hidden="true" title="Edit Picture" id="fa_edit"></i></button>
</div>
@else
<div class="fb-profile"  style="margin-top:21%">
 <img class="thumbnail user_image"  src="{{$users[0]->Image}}" width="200px" height="190px"  alt="Profile image"/>
 <button class="btn btn-default" style="margin-top:-100px" onclick="imgupload()"><i class="fa fa-edit" aria-hidden="true" title="Edit Picture" id="fa_edit"></i></button>
</div>
@endif
</div>
<div class="col-xs-12 col-sm-6 col-md-10" id="kin_info">
 <div class="well" style="background:#fff">
         <div class="container">
         <div class="row" style="width:73%">
             @if(Session::get('user_type') == "User")   
          <ul class="nav nav-tabs preview_tabs">
               <li class="active"><a href="{{url('profile')}}"> <i class="fa fa-cog" aria-hidden="true" id="info_fa"></i> Account Settings</a></li>
               <li><a href="{{url('kindetails')}}"> <i class="fa fa-info" aria-hidden="true" id="info_fa"></i> Kin Details</a></li>
               <a href="{{url('changeemail')}}"><button class="btn btn-primary" style="padding:9px"><i class="fa fa-edit" aria-hidden="true" id="info_fa"></i> change Password</button></a>
              </ul>
             @else
       <ul class="nav nav-tabs preview_tabs">
               <li class="active"><a href="{{url('profile')}}"> <i class="fa fa-cog" aria-hidden="true" id="info_fa"></i> Account Settings</a></li>
                  <a href="{{url('changeemail')}}"><button class="btn btn-primary" style="padding:9px"><i class="fa fa-edit" aria-hidden="true" id="info_fa"></i> change Password</button></a>
             </ul>
             @endif
         <div class="tab-content preview_details">
           <div id="accountsettings" class="tab-pane fade in active" style="margin-top:20px">
             <form class="form-horizontal" action="{{url('editprofile')}}" method="post" style="background:#fff;padding:35px;">
                {{csrf_field()}}
              @if(count($users)>0)
               <div class="col xs-12 col-sm-6 col-md-6 col-lg-6">
                   <input type="hidden" name="AddressId" value="{{$users[0]->AddressId}}">
                     <div class="form-group">
                     <label class="control-label col-sm-4" for="txt">First Name:</label>
                         <div class="col-sm-6">
                           <input type="text" class="form-control" id="txt" name="FirstName" value="{{$users[0]->FirstName}}">
                         </div>
                     </div>
                     <div class="form-group">
                         <label class="control-label col-sm-4" for="txt">Last Name:</label>
                           <div class="col-sm-6">
                             <input type="text" class="form-control" id="txt" name="LastName" value="{{$users[0]->LastName}}">
                           </div>
                    </div>
                     <div class="form-group">
                     <label class="control-label col-sm-4" for="txt">Middle Name:</label>
                       <div class="col-sm-6">
                         <input type="text" class="form-control" id="txt" name="MiddleName" value="{{$users[0]->MiddleName}}">
                       </div>
                   </div>
                    <div class="form-group">
                      <label class="control-label col-sm-4" for="txt">Mobile:</label>
                        <div class="col-sm-6">
                          <input type="text" class="form-control" id="txt" name="DayTimePhone" value="{{$users[0]->DayTimePhone}}">
                        </div>
                    </div>
                      <div class="form-group">
                         <label class="control-label col-sm-4" for="txt">Landline:</label>
                           <div class="col-sm-6">
                             <input type="text" class="form-control" id="txt" name="EveningPhone" value="{{$users[0]->EveningPhone}}">
                           </div>
                       </div>
                   <div class="form-group">
                       <label class="control-label col-sm-4" for="txt">Facebook:</label>
                         <div class="col-sm-6">
                           <input type="text" class="form-control" id="txt" name="Facebook" value="{{$users[0]->Facebook}}">
                         </div>
                  </div>
                 </div>
                 @else
                  <div class="col xs-12 col-sm-6 col-md-6 col-lg-6">
                     <div class="form-group">
                     <label class="control-label col-sm-4" for="txt">First Name:</label>
                         <div class="col-sm-6">
                           <input type="text" class="form-control" id="txt" name="FirstName" value="NA">
                         </div>
                     </div>
                     <div class="form-group">
                         <label class="control-label col-sm-4" for="txt">Last Name:</label>
                           <div class="col-sm-6">
                             <input type="text" class="form-control" id="txt" name="LastName" value="NA">
                           </div>
                    </div>
                     <div class="form-group">
                     <label class="control-label col-sm-4" for="txt">Middle Name:</label>
                       <div class="col-sm-6">
                         <input type="text" class="form-control" id="txt" name="MiddleName" value="NA">
                       </div>
                   </div>
                    <div class="form-group">
                      <label class="control-label col-sm-4" for="txt">Mobile:</label>
                        <div class="col-sm-6">
                          <input type="text" class="form-control" id="txt" name="DayTimePhone" value="NA">
                        </div>
                    </div>
                      <div class="form-group">
                         <label class="control-label col-sm-4" for="txt">Landline:</label>
                           <div class="col-sm-6">
                             <input type="text" class="form-control" id="txt" name="EveningPhone" value="NA">
                           </div>
                       </div>
                   <div class="form-group">
                       <label class="control-label col-sm-4" for="txt">Facebook:</label>
                         <div class="col-sm-6">
                           <input type="text" class="form-control" id="txt" name="Facebook" value="NA">
                         </div>
                  </div>
                 </div>
                 @endif
                 @if(count($address)>0)
                 <div class="col xs-12 col-sm-6 col-md-6 col-lg-6">
                      <div class="form-group">
                       <label class="control-label col-sm-4" for="txt">Address:</label>
                         <div class="col-sm-6">
                           <input type="text" class="form-control" id="txt" name="AddressLine1" value="{{$address[0]->AddressLine1}}">
                         </div>
                   </div>
                      <div class="form-group">
                           <label class="control-label col-sm-4" for="txt">City</label>
                             <div class="col-sm-6">
                               <input type="text" class="form-control" id="txt" name="City" value="{{$address[0]->City}}">
                             </div>
                      </div>
                      <div class="form-group">
                         <label class="control-label col-sm-4" for="file">Postcode:</label>
                           <div class="col-sm-6">
                             <input type="text" class="form-control" id="txt" name="PostCode" value="{{$address[0]->PostCode}}">
                           </div>
                     </div>
                       <div class="form-group">
                         <label class="control-label col-sm-4" for="txt">Country:</label>
                             <div class="col-sm-6">
                                 <input type="text" class="form-control" id="txt" name="Country" value="{{$address[0]->Country}}">
                            </div>
                   </div>
                     <div class="form-group">
                         <label class="control-label col-sm-4" for="txt">Twitter:</label>
                           <div class="col-sm-6">
                             <input type="text" class="form-control" id="txt" name="Twitter" value="{{$address[0]->Twitter}}">
                           </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-4" for="txt">Website:</label>
                          <div class="col-sm-6">
                            <input type="text" class="form-control" id="txt" name="Website" value="{{$address[0]->Website}}">
                          </div>
                   </div>
                    <button type="submit" class="btn btn-primary">Save and Continue</button>


                   </div>
                   @else
                     <div class="col xs-12 col-sm-6 col-md-6 col-lg-6">
                      <div class="form-group">
                       <label class="control-label col-sm-4" for="txt">Address:</label>
                         <div class="col-sm-6">
                           <input type="text" class="form-control" id="txt" name="AddressLine1" value="NA">
                         </div>
                   </div>
                      <div class="form-group">
                           <label class="control-label col-sm-4" for="txt">City</label>
                             <div class="col-sm-6">
                               <input type="text" class="form-control" id="txt" name="City" value="NA">
                             </div>
                      </div>
                      <div class="form-group">
                         <label class="control-label col-sm-4" for="file">Postcode:</label>
                           <div class="col-sm-6">
                             <input type="text" class="form-control" id="txt" name="PostCode" value="NA">
                           </div>
                     </div>
                       <div class="form-group">
                         <label class="control-label col-sm-4" for="txt">Country:</label>
                             <div class="col-sm-6">
                                 <input type="text" class="form-control" id="txt" name="Country" value="NA">
                            </div>
                   </div>
                     <div class="form-group">
                         <label class="control-label col-sm-4" for="txt">Twitter:</label>
                           <div class="col-sm-6">
                             <input type="text" class="form-control" id="txt" name="Twitter" value="NA">
                           </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-4" for="txt">Website:</label>
                          <div class="col-sm-6">
                            <input type="text" class="form-control" id="txt" name="Website" value="NA">
                          </div>
                   </div>
                    
            <button type="submit" class="btn btn-primary">Save and Continue</button>

                   </div>
                   @endif
                 </form>
            </div>
          </div>
        </div>
        </div>
      </div>
  </div>
</div>
<!-- kin information code ends here -->
@endsection