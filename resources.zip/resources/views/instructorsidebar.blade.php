@foreach($instructors as $instructor)
<div class="col-sm-3">
  <div class="row">
  <img align="left" class="image-ins thumbnail" style="margin-top:1%" src="{{$instructor->Image}}" alt="Profile image"/>
</div>
  <div class="row">
    @if(count($favourites)>0)
    <div class="col-sm-1 col-xs-6">
   <a href="{{url('instructor/'.$instructor->ShortName)}}"><i class="fa fa-heart" title="favourite" style="color:#ff6600;font-size:20px"></i></a>
    </div>
      @else
      <div class="col-sm-1 col-xs-6">
   <a href="{{url('instructor/'.$instructor->ShortName.'/following')}}"><i class="fa fa-heart-o" title="favourite" style="color:#ff6600;font-size:20px"></i></a>
    </div>
    @endif
      <div class="col-sm-1 col-xs-6">
     <a href="#"><i class="fa fa-envelope" title="message" style="color:#46A6EA;font-size:20px"></i></a>
   </div><br>
    <div class="col-sm-12 col-xs-12">
      <h5>{{$instructor->ShortName}}</h5>
    </div>
    <div class="col-sm-12 col-xs-12" style="color:#46A6EA;">
      <h5>{{$instructor->UserType}}</h5>
    </div>
     <div class="col-sm-3  col-xs-4">
     <p>Followers <a href="#"><span class="badge">50</span></a></p>
       </div>
       <div class="col-sm-3 col-xs-4">
         <p>Following <a href="#"><span class="badge">70</span></a></p>
       </div>
       @foreach($description as $experience)
       <div class="col-sm-3 col-xs-4">
         <p>Experience<a href="#"> <span class="badge"> {{$experience->Experience}} yrs</span></a></p>
       </div>
        @endforeach
       <br><br>


 </div>
<div class="col-xs-6 col-sm-3">
  <!-- Modal -->
</div>
<div class="modal fade" id="myModal" role="dialog">
                   <div class="modal-dialog">
                     <!-- Modal content-->
                     <div class="modal-content">
                       <div class="modal-body">
                        <div class="form-group">
                           <label class="control-label col-sm-4" for="txt">Name:</label>
                           <div class="col-sm-6">
                           <input type="text" class="form-control" id="txt" name="txt">
                           </div>
                         </div><br><br>
                         <div class="form-group">
                           <label class="control-label col-sm-4" for="txt">Venue:</label>
                           <div class="col-sm-6">
                           <input type="text" class="form-control" id="txt" name="txt">
                           </div>
                         </div><br>
                         <div class="form-group">
                           <label class="control-label col-sm-4" for="txt">Location:</label>
                           <div class="col-sm-6">
                           <input type="text" class="form-control" id="txt" name="txt">
                           </div>
                         </div><br>
                         <div class="form-group">
                           <label class="control-label col-sm-4" for="txt">Start Date:</label>
                           <div class="col-sm-6">
                           <input type="date" class="form-control" id="txt" name="txt">
                           </div>
                         </div><br>
                         <div class="form-group">
                           <label class="control-label col-sm-4" for="txt">End Date:</label>
                           <div class="col-sm-6">
                           <input type="date" class="form-control" id="txt" name="txt">
                           </div>
                         </div><br>
                         <div class="form-group">
                           <label class="control-label col-xs-4 col-sm-4" for="txt">Class Prefered:</label>
                             <div class="col-xs-8 col-sm-6">
                               <label class="radio-inline"><input type="radio" name="optradio">Yes</label>
                                 <label class="radio-inline"><input type="radio" name="optradio">No</label>
                            </div>
                          </div><br>
                       </div>
                       <div class="modal-footer">
                         <div class="col-xs-6 col-sm-6">
                         <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
                       </div>
                       <div class="col-xs-6 col-sm-6">
                       <button type="button" class="btn btn-primary">Submit</button>
                     </div>
                     </div>
                     </div>
                   </div>
                 </div>
</div>
@endforeach