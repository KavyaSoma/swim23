@extends('layouts.main')
@section('content')
<div class="row1">
@if(session()->has('message.level'))
    <div class="alert alert-{{ session('message.level') }}" style="margin:13px;text-align: center;">
    {!! session('message.content') !!}
    </div>
@endif
</div>
    <!-- venue info code starts here -->
<div class="container" id="main-code">
  <div class="row" id="venuepreview_tabs">
    <div class="col-sm-8">
      @foreach($venues as $venue)
        <ul class="nav nav-tabs preview_tabs">
          <li class="active"><a  href="{{url('venue/'.$venue->ShortName)}}"> <i class="fa fa-list" aria-hidden="true" id="info_fa"></i> Basic Details</a></li>
          <li><a href="{{url('venue/'.$venue->ShortName.'/venuepool')}}"> <i class="fa fa-info" aria-hidden="true" id="info_fa"></i> Pool Details</a></li>
          <li><a href="{{url('venue/'.$venue->ShortName.'/venueevents')}}"> <i class="fa fa-calendar" aria-hidden="true" id="info_fa"></i>Events</a></li>
          <li><a  href="{{url('venue/'.$venue->ShortName.'/venueaddress')}}"> <i class="fa fa-map-marker" aria-hidden="true" id="info_fa"></i> Address</a></li>
          <li><a href="{{url('venue/'.$venue->ShortName.'/venuecontact')}}"> <i class="fa fa-phone" aria-hidden="true" id="info_fa"></i> Contact</a></li>
      </ul>
       <div class="tab-content preview_details">
    <div id="venuepreview-basic" class="tab-pane fade in active">
          <form class="form-horizontal">
            <div class="col xs-12 col-sm-12 col-md-12 col-lg-12">
              <div>
                <h4 class="field_names">Venue Name</h4>
              </div>
                <p>{{$venue->VenueName}}</p><hr>
              <div>
                <h4 class="field_names">Short Name</h4>
              </div>
                <p> {{$venue->ShortName}}</p><hr>
              <div>
                <h4 class="field_names">Description</h4>
              </div>
              <p>{{$venue->Description}}</p><hr></div>
         </form>
       </div>
       </div>
    <br><br>
    @endforeach
    </div>
   @include('venuesidebar')

    </div>
  </div>
</div>
@endsection