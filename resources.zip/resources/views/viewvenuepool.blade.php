@extends('layouts.main')
@section('content')
<div class="row1">
@if(session()->has('message.level'))
    <div class="alert alert-{{ session('message.level') }}">
    {!! session('message.content') !!}
    </div>
@endif
    <!-- venue info code starts here -->
<div class="container" id="main-code">
  <div class="row" id="venuepreview_tabs">
    <div class="col-sm-8">
      @foreach($venues as $venue)
         <ul class="nav nav-tabs preview_tabs">
          <li><a  href="{{url('venue/'.$venue->ShortName)}}"> <i class="fa fa-list" aria-hidden="true" id="info_fa"></i> Basic Details</a></li>
          <li class="active"><a href="{{url('venue/'.$venue->ShortName.'/venuepool')}}"> <i class="fa fa-info" aria-hidden="true" id="info_fa"></i> Pool Details</a></li>
          <li><a href="{{url('venue/'.$venue->ShortName.'/venueevents')}}"> <i class="fa fa-calendar" aria-hidden="true" id="info_fa"></i>Events</a></li>
          <li><a  href="{{url('venue/'.$venue->ShortName.'/venueaddress')}}"> <i class="fa fa-map-marker" aria-hidden="true" id="info_fa"></i> Address</a></li>
          <li><a href="{{url('venue/'.$venue->ShortName.'/venuecontact')}}"> <i class="fa fa-phone" aria-hidden="true" id="info_fa"></i> Contact</a></li>
      </ul>
      @endforeach
      <div class="tab-content preview_details">
        <div id="venuepreview-pool" class="tab-pane fade in active">
         <div class="col-sm-12"   style="background:#fff;border:1px solid #ddd;margin-top:30px">
           <div class="row" style="margin-top:20px;">
            @foreach($pools as $pool)
          <div class="panel panel-default  col-md-12">
                             <div class="panel-heading" style="margin-left:-15px;margin-right:-15px;background:#46A6EA;color:#fff"  role="tab">
                                 <h3 class="panel-title">
                                  {{$pool->PoolName}}</a>
                                 </h3>
                             </div>
                            <div class="panel-body">
                               <div class="col xs-12 col-sm-12 col-md-12 col-lg-12">
                                 <div>
                                   <h4 class="field_names">Area</h4>
                                 </div>
                                   <p>{{$pool->Area}}</p>
                                   <div>
                                     <h4 class="field_names">Length</h4>
                                   </div>
                                     <p>{{$pool->Length}}</p>
                                 <div>
                                   <h4 class="field_names">Special Reuirements</h4>
                                 </div>
                                   <p>{{$pool->SpecialRequirements}}</p>
                                 </div>
                            </div>
                         </div>
                         <!-- End fluid width widget -->
                      @endforeach
             </div>
             @if(count($pools)>0)
             <center><ul class="pagination">
{{ $pools->links() }}
 </ul></center>
 @endif
             </div>

     </div>
         </div>
    <br><br>
    </div>
    @include('venuesidebar')
    </div>
  </div>
</div>
<!-- venue info code ends here -->
 @endsection