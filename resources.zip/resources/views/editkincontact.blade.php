@extends('layouts.main')
@section('content')
@if(session()->has('message.level'))
    <div class="alert alert-{{ session('message.level') }}" style="margi-left:13px;">
    {!! session('message.content') !!}
    </div>
    @endif
<div class="container">
        <h5 class="add_venue"><a href="#"><button class="btn btn-primary" style="background-color:#fff;color:#46A6EA"><i class="fa fa-plus"></i></button></a> Add Kin</h5>
  <div class="row" style="border:1px solid #eee">
      <div class="board">
        <div class="board-inner">
          <center><ul class="nav nav-tabs nav_info" id="myTab">
              <div class="liner"></div>
                <li>
                      @foreach($participants as $participant)
                  <a href="{{url('editkin/'.$participant->ParticipantId)}}" class="tab-one" title="Kin Basic Details">
                    <span class="round-tabs">
                      <i class="fa fa-info"></i>
                    </span>
                   </a>
                 </li>
                   <li  class="active">
                      <a href="{{url('kincontact')}}" class="tab-one"  title="Emergency Contact">
                        <span class="round-tabs">
                          <i class="fa fa-phone"></i>
                        </span>
                     </a>
                    </li>
              </ul></center>
          </div>
<div class="tab-pane fade in active" id="kin_contact">
      <form class="form-horizontal" action="{{url('kincontact')}}" style="background:#fff;padding:35px">
        {{csrf_field()}}
            <div class="col-sm-12">
              <div class="form-group">
             <div class="col-sm-offset-4 col-sm-4">
                 <div id="import"><i class="fa fa-plus-circle" style="font-size:20px;color: #46A6EA;"></i> Import Contacts</div>
                  <div id="list" style="display: none;">
                    <div class="form-group">
                     <div class="col-sm-6">
                        <input type="text" class="form-control" id="txt" name="ContactId" required>
                      </div>
                      <div class="col-sm-6">
                         <button class="btn btn-primary">Select</button>
                       </div>
                      </div>
                  </div>
                </div>
           </div>
              <div class="form-group">
                
                    <input type="hidden" name="{{$participant->ParticipantId}}">
                <label class="control-label col-sm-4" for="txt">Contact Name:</label>
                <div class="col-sm-4">
                  <input type="text" class="form-control" id="txt" name="EmergencyContactName" value="{{$participant->EmergencyContactName}}">
                </div>
                </div>
                <div class="form-group">
                <label class="control-label col-sm-4" for="txt">Contact Number:</label>
                <div class="col-sm-4">
                  <input type="text" class="form-control" id="txt" name="EmergencyContactNumber" value="{{$participant->EmergencyContactNumber}}">
                </div>
                </div>
                <div class="form-group">
                <label class="control-label col-sm-4" for="txt">Contact Address:</label>
                <div class="col-sm-4">
                  <input type="text" class="form-control" id="txt" name="EmergencyContactAddress" value="{{$participant->EmergencyContactAddress}}">
                </div>
                </div>
                 @endforeach
                <div class="form-group">
                    <label class="control-label col-sm-4" for="file">Image:</label>
                    <div class="col-sm-4">
                      <input type="file" class="form-control" id="file" name="file">
                    </div>
                  </div>
                  <center>
                     <a href="{{url('addkin')}}">
                       <button class="btn btn-primary">Back</button>
                     </a>
                     <a href="#">
                       <button type="submit" class="btn btn-primary">Save</button><br><br>
                     </a>

                  </div>
                </form>
              </div>
          </div>
        </div>
    </div>
  </div>
 </div>
 </div>
 </div>
 @endsection