@extends('layouts.main')
@section('content')
<!-- mail box code starts here -->
@if(session()->has('message.level'))
    <div class="alert alert-{{ session('message.level') }}" style="margin:13px;text-align: center;">
    {!! session('message.content') !!}
    </div>
    @endif
<div class="container text-center" style="margin-top:20px;" id="main-code">
   <div class="row text-center"> 
    @if( count($events)>0 )
    <table class="table">
        <tr><td>Event Name</td><td>Start Date</td><td>Heat setup</td><td>Results entry</td></tr>    
    @foreach($events as $event)
            <tr><td>{{ $event->EventName }}</td><td></td><td><a href="{{ url('heatsetup/'.$event->EventId)}}" style="color:#000;">setup heats?</a></td><td><a href="" style="color:#000;">results entry?</a></td></tr>
    @endforeach    
    </table>
    @else
    <h4>You have not created any events yet to setup Heats , <a href='{{ url('addevent') }}'>Click here</a> to create an event.</h4>
    @endif
</div>
</div>
</div>
</div>
<!-- mailbox code ends here -->
@endsection    