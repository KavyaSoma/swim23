<h3>SwimmIQ </h3>
<h5>Welcome </h5>
@yield('content')

 